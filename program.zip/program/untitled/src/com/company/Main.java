package com.company;

public class Main {

    public static void main(String[] args) {
//        //zad1
//        java.lang.System.out.println(31 + 29 + 31);
//
//        //zad2
//        int suma = 0;
//        for (int i = 0; i <= 10; i++) {
//            suma += i;
//        }
//        java.lang.System.out.println(suma);
//
//        //zad3
//        int suma2 = 1;
//        for (int i = 1; i < 11; i++) {
//            suma2 *= i;
//        }
//        java.lang.System.out.println(suma2);
//
//        //zad4
//        int money = 1000;
//        for (int i = 0; i < 4; i++) {
//            money *= 1.06;
//        }
//        java.lang.System.out.println(money);
//
//        //zad5
//        java.lang.System.out.println("-----\n" + "|Java|\n" + "-----");
//
//        //zad6
//        java.lang.System.out.println("  /////\n" +
//                " +\"\"\"\"\"+\n" +
//                "(| o o |)\n" +
//                "  | ^ |\n" +
//                " | `-' |\n" +
//                " +-----+");
//
//        //zad7
//        java.lang.System.out.println("*******  *  *      *  *****\n" +
//                "*        *  *      *  *     *\n" +
//                "*******  *  *      *  *     *\n" +
//                "*        *  *      *  *****\n" +
//                "*        *  *      *  *\n" +
//                "*        *  *****  *  *");







































        // zad 8
        java.lang.System.out.println("   +   \n"
                                   + "  + +  \n"
                                   + " +   + \n"
                                   + "+-----+\n"
                                   + "|     |\n"
                                   + "|     |\n"
                                   + "+_+_+_+\n");


//       // Zad 9
//       java.lang.System.out.println(" /\_/\      _____\n"
//                                 +"( ' ' )   / Hello \ \n"
//                                 +"(  -  )  <  Junior |\n"
//                                 +" | | |    \ Coder!/\n"
//                                 +"(__|__)     _____\n");
    }
}
